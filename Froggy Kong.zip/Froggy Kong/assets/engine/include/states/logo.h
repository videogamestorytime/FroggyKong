#ifndef STATE_LOGO_H
#define STATE_LOGO_H

#include <gb/gb.h>

void logo_init() BANKED;
void logo_update() BANKED;

#endif
