#ifndef __STATESCALLER_H_INCLUDE
#define __STATESCALLER_H_INCLUDE

#include <gb/gb.h>

void state_init();
void state_update();

#endif